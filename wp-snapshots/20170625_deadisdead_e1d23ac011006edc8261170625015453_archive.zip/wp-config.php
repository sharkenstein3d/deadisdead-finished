<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'deadisdeDBaxjrj');

/** MySQL database username */
define('DB_USER', 'deadisdeDBaxjrj');

/** MySQL database password */
define('DB_PASSWORD', 'aDVaMSxjp');

/** MySQL hostname */
define('DB_HOST', '127.0.0.1');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'U^vXM.$qI6{jbQ<$uMAynf7{^qeT].xPE6uib2<+TLAymf6{xpe5;_aPD*ti92#eT');
define('SECURE_AUTH_KEY',  '|VK|-sYRJ!zsgC4}kcVN|@voG80ogZR[!wgYQ>^znJB3rkcU},@UNF7vog80>!nfX');
define('LOGGED_IN_KEY',    '|sG4}odVN|@wNG80oYN>^vRJB0rkY4},zVNB@vocME7vnfU>^YQIB$rjB3}^cUJ,');
define('NONCE_KEY',        '2MAMTb.{66DLt+.;*<;WemxiqxAHPXLTbi{2A9HSa~]1_]5Dhp+lt+#LSePWep;6D');
define('AUTH_SALT',        'q.LTaPXem]2E;6ELqx*{]19Hlt-px~#LSalWelt29L6DLTx*#219GOs-_w~#:Wdls');
define('SECURE_AUTH_SALT', 'vFQcbiu$EMTEMTb.{3A{7Ejq$.y^<MXfnmx*DLTaPXem]2E+Xiqt~]Oalaip9LT+');
define('LOGGED_IN_SALT',   'Qj{3BM7FMU$,{$,7bjryy.{PXiqbiqyAIPAIQX*<6<7Ejqy+.]2WepxiqxAHPX');
define('NONCE_SALT',       'h1GFRY@>0|0Ckv!w!JVg0CNQc,0B0BNv^rRUbI${^}7frfr$FQcfq2EX*<6{3ju$');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);define('FS_METHOD', 'direct');

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
